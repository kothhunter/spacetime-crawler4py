#include "Calculator.hpp"

int main() {
    Calculator calc;
    calc.run();
    return 0;
}
